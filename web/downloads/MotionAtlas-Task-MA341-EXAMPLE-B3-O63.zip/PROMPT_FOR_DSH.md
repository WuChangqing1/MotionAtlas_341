/fy-code-animation

# 完成之后 · 第二集（示例） · DeepSeek Harness 制作任务

## 0. 授权与阶段
- 阶段：**card**。只交任务卡、分镜、时间轴和制作方案；不安装依赖、不生成媒体。
- 本任务来自 Motion Atlas 341 工作台真实导出，不是演示占位。
- 不得自动部署、上传、购买第三方服务或进入 final。

## 1. 实际加载 Skill
通过当前 DSH 的 Skill 机制加载 `fy-code-animation`，项目级入口：
`<项目根>/.dsh/skills/fy-code-animation/SKILL.md`
`/fy-code-animation` 只是入口提示；当前 DSH 不支持斜杠时必须使用 skill 工具或手动读取 SKILL.md，并在制作记录里说明实际加载方式。至少读取：
- `modules/decisions.md`
- `modules/workflow.md`
- `modules/meaning.md`
- `modules/style.md`
- `modules/engineering.md`
- `modules/qa.md`

## 2. 风格库自检
```powershell
python .dsh/skills/fy-code-animation/scripts/style_library.py build --root ./style-library
python .dsh/skills/fy-code-animation/scripts/doctor.py --root ./style-library
python .dsh/skills/fy-code-animation/scripts/style_library.py get --root ./style-library --query B3
```
若 doctor 不通过，停止并报告缺项，不得假称已读取风格。

## 3. 选定风格与角色
1. [辅助特效] B3 粒子聚形
   原文：风格提示词/A-G_代码样片/B3_粒子聚形.md
   SHA256：2a784814e01c2ca003b6c5c2ddb1cffb84b0f57f45e6416543b95eecaaf66af1
2. [主视觉风格] O63 与狼共舞
   原文：风格提示词/O_奥斯卡98部/O63_与狼共舞.md
   SHA256：a9ad027c6b13ce25a58b8b9f23d09fddb8b4ef067f8677bcba7e2e8a5c44e4fe

组合方式：**主风格 + 辅助特效**
- O63：主视觉。负责纸张、印刷、物件和整体色彩；先按原文确认材料与构图。
- B3：辅助特效。只在机械臂入座、视觉复核和数据显现处使用；粒子不能遮挡实体、文字或关键抓取点。
- 不得把两份完整 Prompt 机械拼接；冲突时保留作者选择并说明折中。

## 4. 制作需求
- 主题：动作完成 ≠ 任务完成
- 观众：产品团队与自动化验收人员
- 核心：执行动作并不等于任务目标已经得到可靠验证。
- 关键事实：机械臂抓取、放置、视觉复核；6.2 mm、+23°、71% 均仅作模拟演示数据。
- 文案/故事：机械臂完成一次抓取与放置，检测系统却给出未通过的复核证据。画面最后说明：动作完成不等于任务完成，纠正指令仍需执行。
- 时长：15s；画幅：16:9；分辨率：1920x1080；30fps
- 字幕：中文；声音：无音乐 / 按镜头设计音效 / 不需要旁白
- 角色：不需要
- 输出：HTML + Canvas 可运行工程 + 静帧/视频
- 特别要求：中文大字可读；O63 负责纸张、物件与整体气质；B3 只负责粒子入座/复核特效，不覆盖主体和文字。
- 禁止：不自动部署；不上传未公开文案；不使用外部付费素材；不把模拟测量写成实测。

## 5. 执行流程
1. 先阅读全文，提炼语义、事实边界、观众认识变化和情绪走向；写理解摘要。
2. 完整读取 B3、O63 原文，记录依赖、材料、动作语法、技术限制与参考出处。
3. 按 `templates/task-card.md` 输出 card：分镜、时间轴、画面、文字、镜头、转场、声音需求和待确认项。
4. 不生成媒体、不安装依赖；若发现风格冲突，提出方案让作者选择。

## 6. 完成标准
- 交付任务卡/分镜，不是空泛方案；
- 引用真实原文路径与 SHA；
- 主视觉与辅助特效职责清楚；
- 区分机器检查、人工观看、作者采用；
- 说明未完成项和风险；
- 不虚构 Skill 调用或制作结果。

## 7. 完工汇报
列出实际读取的 Skill 模块、风格原文/SHA、生成文件、运行命令、真实结果、遗留问题。