# Skill 安装

## A. 已有 MotionAtlas_341 工程
直接使用项目 `.dsh/skills/fy-code-animation/` 与 `style-library/`。

## B. 其他工作区
将完整 `fy-code-animation` 复制到目标项目 `.dsh/skills/`，将原始 341 风格库放到含 `风格提示词/` 的根目录，再运行 build/doctor。缺少依赖时不要直接宣称可用。