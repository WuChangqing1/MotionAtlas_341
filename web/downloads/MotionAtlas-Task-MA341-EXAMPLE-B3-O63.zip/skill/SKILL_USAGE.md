# Skill 调用说明

- 项目级 Skill：`.dsh/skills/fy-code-animation/SKILL.md`
- 通过 DSH skill 工具加载 `fy-code-animation`；`/fy-code-animation` 只是入口。
- 如果当前 DSH 不支持斜杠，手动读取 SKILL.md，并读取 modules/workflow.md、decisions.md、meaning.md、style.md、engineering.md、qa.md。
- card 只设计；still 只静帧；audition 只试听；final 需要明确授权。
- 判定真实调用的证据：实际读取文件、style_library build/doctor/get 的真实输出、任务卡中的 SHA 和依赖。