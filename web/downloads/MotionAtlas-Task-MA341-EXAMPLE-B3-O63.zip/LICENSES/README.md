# 许可与来源

- 风格库许可：见 `LICENSES/style-library-license.md`
- Skill 许可：见 `LICENSES/skill-LICENSE.md`
- 第三方来源：见 `LICENSES/third-party/`
- 风格原文参考出处见 `styles/selected/` 末尾。

免费分享；不得包装成付费课程、付费 skill 或收费资料出售。参考图仅作风格判断。