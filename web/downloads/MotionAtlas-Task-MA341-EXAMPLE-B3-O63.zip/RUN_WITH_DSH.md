# Windows 11 · 运行示例任务

## 解压
```powershell
Expand-Archive -LiteralPath .\MotionAtlas-Task-MA341-EXAMPLE-B3-O63.zip -DestinationPath . -Force
cd .\MotionAtlas-Task-MA341-EXAMPLE-B3-O63
```

## 确认工作区
把任务包放入已安装完整 Skill 与 341 风格库的 MotionAtlas_341 工作区，或使用包含 `skill/` 的完整包。确认：
```powershell
Test-Path .\.dsh\skills\fy-code-animation\SKILL.md
Test-Path .\style-library\风格提示词
python .\.dsh\skills\fy-code-animation\scripts\style_library.py build --root .\style-library
python .\.dsh\skills\fy-code-animation\scripts\doctor.py --root .\style-library
```

## 加载 Skill
在 DSH 中调用 skill 工具加载 `fy-code-animation`，或手动读取项目内 SKILL.md。不要只输入 `/fy-code-animation` 就假定加载成功。

## 交给 DSH
把 `PROMPT_FOR_DSH.md` 全文交给 DSH。默认阶段为 **card**；不要擅自升级到 final。

## 检查
查看 DSH 是否输出任务卡、分镜、风格引用 SHA、待确认项，以及是否明确没有生成媒体。