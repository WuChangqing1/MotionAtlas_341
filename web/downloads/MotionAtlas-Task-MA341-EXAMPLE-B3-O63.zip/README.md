# MA341-EXAMPLE-B3-O63

完成之后 · 第二集（示例）

- 阶段：card
- 风格：B3（辅助特效）+ O63（主视觉）
- 任务：动作完成 ≠ 任务完成
- 输出：任务卡/分镜

先读 RUN_WITH_DSH.md，再把 PROMPT_FOR_DSH.md 交给 DSH。